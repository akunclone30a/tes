
## CATATAN
Script ini gratis untuk semua orang, bukan untuk Dijual. Jika dijual neraka menunggumu Brother!!
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
<p align="center">
    <img src="https://telegra.ph/file/8a1c663c84751c10baf65.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
</p>

## PENTING

> **Warning**: Script Ini Tidak Support Qr Untuk Saat Ini, Jadi Kalian Bisa Menggunakan Replit Untuk Mengambil Session Atau
Memakai Sc Lain Untuk Mengambil Session Atau Kalau Kalian Masih pengguna Satu Sesi Bisa Pakai main.js.bak yg sudah saya sediakan

<h1 align="center">RullBOT - MD</h1>
<p align="center">
  <a href="https://github.com/RullDev"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Rull+BOT+Multi+Device;Base+ori+by+BochilGaming;Recode+By+RullSenpai;Give+star+and+forks+this+Repo+:D;Follow+My+Github" alt="ʘᴗʘ">
</p>

<p align="center">
 <a href="#"><img title="RullBOT" src="https://img.shields.io/badge/Whatshapp BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/RullDev"><img title="Author" src="https://img.shields.io/badge/AUTHOR-ImYanXiao-green.svg?style=for-the-badge&logo=github"></a>

---------

## ```Connect With Me 📞``` 

## ```Whatsapp``` <a href="https://wa.me/6287753812675"> <img align="left" alt="SIEGRIN | Whastapp" width="26px" src="https://github.com/siegrin/siegrin/blob/main/Assets/Whatsapp.svg" />
[![BOT WHATSAPP](https://img.shields.io/badge/WhatsApp%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6287753812675) 
---------

### a little about this bot
- ✔️ | **Simple** 
- ✔️ | **Button Template** 
- ✔️ | **Multi Device** 
- ✔️ | **Button Document(Experiment)** 
---------
### Some of the features include
- ✔️ | Downloader 
- ✔️ | Internet 
- ✔️ | Game Rpg 
- ✔️ | Nsfw 
- ✔️ | Sticker 
- ✔️ | Game 
- ✔️ | Kerang Ajaib 
- ✔️ | Quotes
- ✔️ | Anime 
- ✔️ | Premium 
- ✔️ | Tools 
- ✔️ | Exec 
- ✔️ | React 
- ✔️ | Menfess Balas
---------

## ```For User Panel, Buy Panel In This Number```
[![WHATSAPP](https://img.shields.io/badge/Seller%20Panel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6285692006004) 
---------

## ```USER RAILWAY```

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/ImYanXiao/Elaina-MultiDevice)

## ```USER REPLIT```
[![Run on Repl.it](https://repl.it/badge/github/ImYanXiao/Elaina-MultiDevice)](https://repl.it/github/ImYanXiao/Elaina-MultiDevice)

---------

## ```Nama Session```
[<rullzy.data.json>]

## `--self`
* Activate self mode (Ignores other)

## `--pconly`
* If that chat not from private bot, bot will ignore

## `--gconly`
* If that chat not from group, bot will ignore

## `--swonly`
* If that chat not from status, bot will ignore

## `--prefix <prefixes>`
* `prefixes` are seperated by each character
Set prefix

## `--server`
* Used for [heroku](https://heroku.com/) or scan through website

## `--restrict`
* Enables restricted plugins (which can lead your number to be **banned** if used too often)
* Group Administration `add, kick`

## `--img`
* Enable image inspector through terminal

## `--autoread`
* If enabled, all incoming messages will be marked as read

## `--nyimak`
* No bot, just print received messages and add users to database

## `--test`
* **Development** Testing Mode

---------

### 📮 S&K
1. Not For Sale
2. Don't forget give star this repo
3. Follow Github
4. Don't use this repository wrong!
5. If you have problem chat me in owner number

---------

### ❗ Note : Untuk apikey kamu bisa beli ke website itu sendiri :D

---------

## ```Thanks to ✨```
* [`Allah SWT`](https://github.com/RullDev)
* [`My parents`](https://github.com/RullDev)
* [`All Friends`](https://github.com/RullDev)
* [`All Contributors`](https://github.com/RullDev)
* [`All Creator Bot`](https://github.com/RullDev)
* [`Adiwajshing`](https://github.com/adiwajshing/Baileys)
* [`Nurutomo`](https://github.com/nurutomi)
* [`BochilGaming`](https://github.com/bochilgaming)
* [`KannaChann`](https://github.com/kannachann) 
* [`The.Sad.Boy01`](https://github.com/Kangsad01) 
* [`Papah-Chan`](https://github.com/FahriAdison) 

## ```Recode By ✏️```
[![KhrlMstfa](https://telegra.ph/file/8a1c663c84751c10baf65.jpg?size=20)](https://github.com/RullDev)