let handler = async (m, { conn, participants }) => {
 m.reply('Waalaikumsalam')
      }
           handler.help = ['Assalamualaikum']
                handler.tags = ['quran']
                     
                          handler.customPrefix = /^Assalamualaikum|Assalamu'alaikum$/i
                               handler.command = new RegExp
                                    module.exports = handler