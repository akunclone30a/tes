## New Update

**Pembaruan :**
- Telah menggunakan multi auth sessions 
- Fix QR code di terminal & pairing code
- Use Pairing Code: ```node . --pairing 62xxxxxxxxxx```
- Use QR Code: ```node .```
- Penambahan Fitur Store ```addlist, dellist, updatelist, list```

 ## WAJIB MENGGUNAKAN WEB API DI BAWAH
  
- BetaBotz API [`RestApi`](https://api.betabotz.org)
  
- Botcahx API [`RestApi`](https://api.botcahx.eu.org)

- LolHuman API [`RestApi`](https://api.lolhuman.xyz)

- Itsrose API [`RestApi`](https://docs.itsrose.life)

## GRUP & NOMOR SAYA
- Owner Bot [`Chat Saya`](https://wa.me/6283823253378)

- Group Bot [`Join`](https://chat.whatsapp.com/DEyTlYgAowu2eeXJb5Q0SP)

- Group Genshin [`Join`](https://chat.whatsapp.com/LZCnnSQFPkF3C6zrDcH5n8)

## UNTUK PENGGUNA WINDOWS/VPS/RDP

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)
* Unduh & Instal ImageMagick [`Klik Disini`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/ketchupmaze/MXYULA-MD
cd MXYULA-MD
npm install
npm start
```


##### All Contributors
<a href="https://github.com/BOTCAHX"><img src="https://github.com/BOTCAHX.png?size=100" width="100" height="100"></a> | [![Erlan](https://github.com/ERLANRAHMAT.png?size=100)](https://github.com/ERLANRAHMAT) 
---|---
[Tio](https://github.com/BOTCAHX)  | [Erlan](https://github.com/ERLANRAHMAT)
Contributor | Contributor |
