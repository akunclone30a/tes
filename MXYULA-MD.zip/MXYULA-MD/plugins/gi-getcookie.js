/*let handler = async m => m.reply(`
javascript:script:check = document.cookie.includes('ltoken') && document.cookie.includes('ltuid') || alert('Please logout and log back in before trying again, cookie is currently expired/invalid!'); cookie = document.cookie; check && document.write(`<p>${cookie}</p><br><button onclick="navigator.clipboard.writeText('${cookie}')">Click here to copy!</button><br>`)
`.trim()) // Tambah sendiri kalo mau
handler.help = ['getcookie']
handler.tags = ['info']
handler.command = /^(getcookie)$/i
module.exports = handler*/
